package poly.com.controller;

import java.io.File;
import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@MultipartConfig()
@WebServlet("/upload")
public class Lab4bai4controller extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Đường dẫn tương đối nơi lưu file trên server
    private static final String UPLOAD_DIR = "/static/files/";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // Chuyển hướng đến trang JSP chứa form
        req.getRequestDispatcher("/upload.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            // 1. Lấy Part (phần file) từ request với name="photo"
            Part photoPart = req.getPart("photo");
            String fileName = photoPart.getSubmittedFileName();
            
            // 2. Xây dựng đường dẫn vật lý để lưu file
            // path = [thư mục gốc của webapp]/static/files/[tên file]
            String pathRelative = UPLOAD_DIR + fileName;
            String pathPhysical = req.getServletContext().getRealPath(pathRelative);

            // 3. Đảm bảo thư mục lưu trữ tồn tại
            File uploadDir = new File(req.getServletContext().getRealPath(UPLOAD_DIR));
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }

            // 4. Ghi file vật lý vào server
            photoPart.write(pathPhysical);
            
            // Đặt thông báo thành công và đường dẫn URL để hiển thị ảnh
            req.setAttribute("message", "Tải file thành công! Tên file: " + fileName);
            req.setAttribute("photoURL", pathRelative); 
            
        } catch (Exception e) {
            req.setAttribute("message", "Lỗi tải file: " + e.getMessage());
        }
        
        // 5. Chuyển tiếp lại trang JSP
        req.getRequestDispatcher("/upload.jsp").forward(req, resp);
    }
}