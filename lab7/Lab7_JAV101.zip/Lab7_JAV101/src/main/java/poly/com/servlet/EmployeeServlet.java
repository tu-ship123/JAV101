package poly.com.servlet;

import java.io.File;
import java.io.IOException;
import java.util.List;

// --- Dùng thư viện JAKARTA ---
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import org.apache.commons.beanutils.BeanUtils;
// Import Interface và Class Impl cho đúng chuẩn
import poly.com.dao.DepartmentDAO; 
import poly.com.dao.DepartmentDAOImpl;
import poly.com.dao.EmployeeDAO;
import poly.com.entity.Employee;
import poly.com.entity.Department;

@MultipartConfig // BẮT BUỘC ĐỂ UPLOAD ẢNH
@WebServlet({"/employee/index", "/employee/create", "/employee/update", "/employee/delete", "/employee/edit/*", "/employee/reset"})
public class EmployeeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Thiết lập tiếng Việt
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        EmployeeDAO dao = new EmployeeDAO();
        Employee form = new Employee();
        
        try {
            // 1. Đổ dữ liệu từ form vào object (Dùng BeanUtils)
            // Lưu ý: BeanUtils có thể lỗi với ngày tháng nếu ô ngày bị rỗng
            BeanUtils.populate(form, req.getParameterMap());
            
            // 2. Xử lý Upload ảnh
            Part part = req.getPart("photo_file"); 
            
            if (part != null && part.getSize() > 0 && part.getSubmittedFileName() != null && !part.getSubmittedFileName().isEmpty()) {
                String filename = part.getSubmittedFileName();
                String realPath = req.getServletContext().getRealPath("/images");
                File dir = new File(realPath);
                
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                
                part.write(realPath + File.separator + filename);
                form.setPhoto(filename);
            } else {
                // Giữ lại ảnh cũ
                String oldPhoto = req.getParameter("photo");
                form.setPhoto(oldPhoto);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }

        String path = req.getServletPath();
        
        // 3. Điều hướng chức năng (Routing)
        try {
            if (path.contains("edit")) {
                if (req.getPathInfo() != null && req.getPathInfo().length() > 1) {
                    String id = req.getPathInfo().substring(1);
                    form = dao.findById(id);
                }
            } else if (path.contains("create")) {
                dao.create(form);
                req.setAttribute("message", "Thêm mới thành công!");
                form = new Employee(); 
            } else if (path.contains("update")) {
                dao.update(form);
                req.setAttribute("message", "Cập nhật thành công!");
            } else if (path.contains("delete")) {
                dao.delete(form.getId());
                req.setAttribute("message", "Xóa thành công!");
                form = new Employee();
            } else {
                form = new Employee();
            }
        } catch (Exception e) {
            req.setAttribute("message", "Lỗi: " + e.getMessage());
        }

        // 4. Chuẩn bị dữ liệu đẩy sang JSP
        req.setAttribute("item", form);
        
        // --- LOGIC TÌM KIẾM (MỚI THÊM) ---
        String keyword = req.getParameter("keyword");
        List<Employee> list;
        
        if (keyword != null && !keyword.trim().isEmpty()) {
            // Nếu có từ khóa -> Gọi hàm tìm kiếm
            list = dao.findByName(keyword);
        } else {
            // Nếu không -> Lấy tất cả
            list = dao.findAll();
        }
        req.setAttribute("list", list);
        // ----------------------------------
        
        // Lấy danh sách phòng ban
        DepartmentDAO deptDao = new DepartmentDAOImpl();
        List<Department> deptList = deptDao.findAll(); // Hoặc selectAll() tùy tên hàm bên DAO của bạn
        req.setAttribute("depts", deptList);
        
        // 5. Hiển thị giao diện
        // Sửa đường dẫn trỏ vào thư mục views
        req.getRequestDispatcher("/views/employee.jsp").forward(req, resp);
    }
}