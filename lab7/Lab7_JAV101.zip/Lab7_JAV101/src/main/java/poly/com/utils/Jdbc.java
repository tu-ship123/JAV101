package poly.com.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Jdbc {
    // Thông tin kết nối [cite: 107-109]
    private static String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    private static String dburl = "jdbc:sqlserver://localhost;databaseName=HRM_JAV101_Lab6;encrypt=true;trustServerCertificate=true;";
    private static String username = "sa"; // Thay bằng user của bạn
    private static String password = "123456"; // Thay bằng pass của bạn

    // Nạp driver khi class được load [cite: 110-120]
    static {
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    // Mở kết nối [cite: 123-125]
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(dburl, username, password);
    }

    // Phương thức thao tác (INSERT, UPDATE, DELETE) [cite: 127-134]
    // Sử dụng PreparedStatement để truyền tham số động (dấu ?)
    public static int executeUpdate(String sql, Object... args) {
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            for (int i = 0; i < args.length; i++) {
                stmt.setObject(i + 1, args[i]);
            }
            return stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Phương thức truy vấn (SELECT) [cite: 136-144]
    public static ResultSet executeQuery(String sql, Object... args) {
        try {
            Connection conn = getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql);
            for (int i = 0; i < args.length; i++) {
                stmt.setObject(i + 1, args[i]);
            }
            return stmt.executeQuery();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
