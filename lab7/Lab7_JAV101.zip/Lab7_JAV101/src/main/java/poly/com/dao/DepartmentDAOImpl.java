package poly.com.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import poly.com.entity.Department;
import poly.com.utils.Jdbc;

public class DepartmentDAOImpl implements DepartmentDAO {

    @Override
    public List<Department> findAll() {
        String sql = "SELECT * FROM Departments";
        try {
            List<Department> list = new ArrayList<>();
            ResultSet rs = Jdbc.executeQuery(sql);
            while (rs.next()) {
                Department entity = new Department();
                entity.setId(rs.getString("Id"));
                entity.setName(rs.getString("Name"));
                entity.setDescription(rs.getString("Description"));
                list.add(entity);
            }
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Department findById(String id) {
        String sql = "SELECT * FROM Departments WHERE Id=?";
        try {
            ResultSet rs = Jdbc.executeQuery(sql, id);
            if (rs.next()) {
                Department entity = new Department();
                entity.setId(rs.getString("Id"));
                entity.setName(rs.getString("Name"));
                entity.setDescription(rs.getString("Description"));
                return entity;
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    @Override
    public void create(Department entity) {
        String sql = "INSERT INTO Departments (Id, Name, Description) VALUES(?, ?, ?)";
        Jdbc.executeUpdate(sql, entity.getId(), entity.getName(), entity.getDescription());
    }

    @Override
    public void update(Department entity) {
        String sql = "UPDATE Departments SET Name=?, Description=? WHERE Id=?";
        Jdbc.executeUpdate(sql, entity.getName(), entity.getDescription(), entity.getId());
    }

    @Override
    public void deleteById(String id) {
        String sql = "DELETE FROM Departments WHERE Id=?";
        Jdbc.executeUpdate(sql, id);
    }

    // --- MỚI THÊM: TRIỂN KHAI HÀM TÌM KIẾM ---
    @Override
    public List<Department> findByName(String keyword) {
        String sql = "SELECT * FROM Departments WHERE Name LIKE ? OR Id LIKE ?";
        List<Department> list = new ArrayList<>();
        try {
            String key = "%" + keyword + "%";
            // Tìm theo Tên hoặc Mã phòng
            ResultSet rs = Jdbc.executeQuery(sql, key, key);
            while (rs.next()) {
                Department entity = new Department();
                entity.setId(rs.getString("Id"));
                entity.setName(rs.getString("Name"));
                entity.setDescription(rs.getString("Description"));
                list.add(entity);
            }
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}