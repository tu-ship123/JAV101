package poly.com.servlet;

import java.io.IOException;
import java.util.List;

// --- Dùng thư viện JAKARTA ---
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
// -----------------------------

import org.apache.commons.beanutils.BeanUtils;
import poly.com.dao.DepartmentDAO;
import poly.com.dao.DepartmentDAOImpl;
import poly.com.entity.Department;

@WebServlet({"/department/index", "/department/create", "/department/update", "/department/delete", "/department/reset", "/department/edit/*"})
public class DepartmentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 1. Thiết lập tiếng Việt
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        DepartmentDAO dao = new DepartmentDAOImpl();
        Department form = new Department();
        
        // 2. Đổ dữ liệu từ form vào object
        try {
            BeanUtils.populate(form, req.getParameterMap());
        } catch (Exception e) {
            e.printStackTrace();
        }

        String path = req.getServletPath();
        
        // 3. Xử lý chức năng (Routing)
        try {
            if (path.contains("edit")) {
                if (req.getPathInfo() != null && req.getPathInfo().length() > 1) {
                    String id = req.getPathInfo().substring(1); 
                    form = dao.findById(id);
                }
            } else if (path.contains("create")) {
                dao.create(form);
                req.setAttribute("message", "Thêm mới thành công!");
                form = new Department(); 
            } else if (path.contains("update")) {
                dao.update(form);
                req.setAttribute("message", "Cập nhật thành công!");
            } else if (path.contains("delete")) {
                dao.deleteById(form.getId());
                req.setAttribute("message", "Xóa thành công!");
                form = new Department();
            } else {
                form = new Department();
            }
        } catch (Exception e) {
            req.setAttribute("message", "Lỗi: " + e.getMessage());
            e.printStackTrace();
        }

        // 4. Chuẩn bị dữ liệu hiển thị
        req.setAttribute("item", form);
        
        // --- LOGIC TÌM KIẾM (MỚI THÊM) ---
        String keyword = req.getParameter("keyword");
        List<Department> list;
        
        if (keyword != null && !keyword.trim().isEmpty()) {
            list = dao.findByName(keyword); // Gọi hàm tìm kiếm vừa thêm ở bước trước
        } else {
            list = dao.findAll(); // Mặc định lấy tất cả
        }
        req.setAttribute("list", list);
        // ----------------------------------
        
        // 5. Chuyển hướng về trang JSP
        // LƯU Ý: Bạn kiểm tra xem file department.jsp của bạn nằm trong thư mục 'views' hay ở ngoài 'webapp'
        // Nếu ở ngoài webapp thì xóa chữ /views đi nhé.
        req.getRequestDispatcher("/views/department.jsp").forward(req, resp);
    }
}