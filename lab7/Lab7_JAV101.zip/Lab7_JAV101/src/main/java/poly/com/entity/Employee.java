package poly.com.entity;

public class Employee {
    private String id;
    private String password; // Bổ sung cho khớp DB
    private String name;     // Sẽ map với cột Fullname trong DB
    private String photo;
    private boolean gender;
    private String birthday; // Bổ sung cho khớp DB (để String cho dễ xử lý với input date)
    private Double salary;
    private String departId; // Sẽ map với cột DepartmentId trong DB

    // Constructor không tham số
    public Employee() {
    }

    // Constructor đầy đủ tham số (để tiện dùng nếu cần)
    public Employee(String id, String password, String name, String photo, boolean gender, String birthday, Double salary, String departId) {
        this.id = id;
        this.password = password;
        this.name = name;
        this.photo = photo;
        this.gender = gender;
        this.birthday = birthday;
        this.salary = salary;
        this.departId = departId;
    }

    // --- GETTER & SETTER ---

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public boolean isGender() {
        return gender;
    }

    public void setGender(boolean gender) {
        this.gender = gender;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }

    public String getDepartId() {
        return departId;
    }

    public void setDepartId(String departId) {
        this.departId = departId;
    }
}