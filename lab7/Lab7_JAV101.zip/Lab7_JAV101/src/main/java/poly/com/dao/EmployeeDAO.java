package poly.com.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import poly.com.entity.Employee;
import poly.com.utils.Jdbc;

public class EmployeeDAO {
    
    // 1. Lấy danh sách
    public List<Employee> findAll() {
        String sql = "SELECT * FROM Employees";
        List<Employee> list = new ArrayList<>();
        try {
            ResultSet rs = Jdbc.executeQuery(sql);
            while (rs.next()) {
                Employee e = new Employee();
                e.setId(rs.getString("Id"));
                e.setPassword(rs.getString("Password")); 
                e.setName(rs.getString("Fullname"));     
                e.setGender(rs.getBoolean("Gender"));
                e.setBirthday(rs.getString("Birthday")); 
                e.setSalary(rs.getDouble("Salary"));
                e.setPhoto(rs.getString("Photo"));
                e.setDepartId(rs.getString("DepartmentId")); 
                list.add(e);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    // 2. Thêm mới
    public void create(Employee e) {
        String sql = "INSERT INTO Employees (Id, Password, Fullname, Photo, Gender, Birthday, Salary, DepartmentId) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        // Kiểm tra phòng ban, nếu null thì gán P01
        String deptId = (e.getDepartId() == null || e.getDepartId().isEmpty()) ? "P01" : e.getDepartId();

        Jdbc.executeUpdate(sql, 
            e.getId(), 
            e.getPassword(),  
            e.getName(), 
            e.getPhoto(), 
            e.isGender(), 
            e.getBirthday(), 
            e.getSalary(), 
            deptId            
        );
    }

    // 3. Cập nhật
    public void update(Employee e) {
        String sql = "UPDATE Employees SET Password=?, Fullname=?, Photo=?, Gender=?, Birthday=?, Salary=?, DepartmentId=? WHERE Id=?";
        
        // Kiểm tra phòng ban, nếu null thì gán P01
        String deptId = (e.getDepartId() == null || e.getDepartId().isEmpty()) ? "P01" : e.getDepartId();

        Jdbc.executeUpdate(sql, 
            e.getPassword(), 
            e.getName(), 
            e.getPhoto(), 
            e.isGender(), 
            e.getBirthday(), 
            e.getSalary(), 
            deptId,           
            e.getId()
        );
    }

    // 4. Xóa
    public void delete(String id) {
        String sql = "DELETE FROM Employees WHERE Id=?";
        Jdbc.executeUpdate(sql, id);
    }
    
    // 5. Tìm theo ID (Dùng cho chức năng Edit)
    public Employee findById(String id) {
        String sql = "SELECT * FROM Employees WHERE Id=?";
        try {
            ResultSet rs = Jdbc.executeQuery(sql, id);
            if(rs.next()){
                Employee e = new Employee();
                e.setId(rs.getString("Id"));
                e.setPassword(rs.getString("Password")); 
                e.setName(rs.getString("Fullname"));     
                e.setGender(rs.getBoolean("Gender"));
                e.setBirthday(rs.getString("Birthday")); 
                e.setSalary(rs.getDouble("Salary"));
                e.setPhoto(rs.getString("Photo"));
                e.setDepartId(rs.getString("DepartmentId")); 
                return e;
            }
        } catch (Exception ex) { ex.printStackTrace(); }
        return null;
    }

    // --- 6. TÌM KIẾM THEO TÊN HOẶC MÃ (MỚI THÊM) ---
    public List<Employee> findByName(String keyword) {
        String sql = "SELECT * FROM Employees WHERE Fullname LIKE ? OR Id LIKE ?";
        List<Employee> list = new ArrayList<>();
        try {
            // Thêm dấu % để tìm gần đúng (chứa từ khóa)
            String key = "%" + keyword + "%";
            
            // Truyền tham số key 2 lần (1 cho Fullname, 1 cho Id)
            ResultSet rs = Jdbc.executeQuery(sql, key, key);
            
            while (rs.next()) {
                Employee e = new Employee();
                e.setId(rs.getString("Id"));
                e.setPassword(rs.getString("Password"));
                e.setName(rs.getString("Fullname"));
                e.setGender(rs.getBoolean("Gender"));
                e.setBirthday(rs.getString("Birthday"));
                e.setSalary(rs.getDouble("Salary"));
                e.setPhoto(rs.getString("Photo"));
                e.setDepartId(rs.getString("DepartmentId"));
                list.add(e);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}