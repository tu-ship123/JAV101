
CREATE DATABASE HRM_JAV101_Lab6_7;
GO

USE HRM_JAV101_Lab6_7;
GO

CREATE TABLE Departments (
    Id CHAR(3) NOT NULL PRIMARY KEY,      
    Name NVARCHAR(50) NOT NULL,           
    Description NVARCHAR(255) NULL       
);
GO


CREATE TABLE Employees (
    Id VARCHAR(20) NOT NULL PRIMARY KEY,  
    Password NVARCHAR(50) NOT NULL,       
    Fullname NVARCHAR(50) NOT NULL,       
    Photo NVARCHAR(255) NULL,            
    Gender BIT NOT NULL,                  
    Birthday DATE NOT NULL,               
    Salary FLOAT NOT NULL,               
    DepartmentId CHAR(3) NOT NULL,        
    

    FOREIGN KEY (DepartmentId) REFERENCES Departments(Id) 
    ON DELETE CASCADE ON UPDATE CASCADE
);
GO
