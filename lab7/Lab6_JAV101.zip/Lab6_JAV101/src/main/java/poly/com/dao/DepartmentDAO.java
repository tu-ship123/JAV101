package poly.com.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import poly.com.model.Department;
import poly.com.utils.Jdbc;

public class DepartmentDAO {
    
    // Lấy tất cả phòng ban
    public List<Department> selectAll() {
        String sql = "SELECT * FROM Departments";
        List<Department> list = new ArrayList<>();
        try {
            ResultSet rs = Jdbc.executeQuery(sql);
            while(rs.next()){
                Department dep = new Department();
                dep.setId(rs.getString("Id"));
                dep.setName(rs.getString("Name"));
                dep.setDescription(rs.getString("Description"));
                list.add(dep);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    // Bạn có thể thêm insert, update, delete cho Department nếu muốn làm thêm bài quản lý phòng ban
}