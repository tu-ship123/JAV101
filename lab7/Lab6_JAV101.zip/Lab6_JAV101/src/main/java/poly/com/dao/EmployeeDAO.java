package poly.com.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import poly.com.model.Employee;
import poly.com.utils.Jdbc; // Import class Jdbc cũ của bạn

public class EmployeeDAO {

    // 1. Thêm mới
    public void insert(Employee model) {
        String sql = "INSERT INTO Employees (Id, Password, Fullname, Photo, Gender, Birthday, Salary, DepartmentId) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        Jdbc.executeUpdate(sql, 
            model.getId(), 
            model.getPassword(), 
            model.getFullname(), 
            model.getPhoto(), 
            model.isGender(), 
            model.getBirthday(), 
            model.getSalary(), 
            model.getDepartmentId()
        );
    }

    // 2. Cập nhật
    public void update(Employee model) {
        String sql = "UPDATE Employees SET Password=?, Fullname=?, Photo=?, Gender=?, Birthday=?, Salary=?, DepartmentId=? WHERE Id=?";
        Jdbc.executeUpdate(sql, 
            model.getPassword(), 
            model.getFullname(), 
            model.getPhoto(), 
            model.isGender(), 
            model.getBirthday(), 
            model.getSalary(), 
            model.getDepartmentId(),
            model.getId()
        );
    }

    // 3. Xóa
    public void delete(String id) {
        String sql = "DELETE FROM Employees WHERE Id=?";
        Jdbc.executeUpdate(sql, id);
    }

    // 4. Lấy danh sách (có hỗ trợ tìm kiếm)
    public List<Employee> selectAll(String keyword) {
        String sql = "SELECT * FROM Employees";
        if (keyword != null && !keyword.isEmpty()) {
            sql += " WHERE Fullname LIKE ?";
        }

        List<Employee> list = new ArrayList<>();
        try {
            ResultSet rs = (keyword != null && !keyword.isEmpty()) 
                            ? Jdbc.executeQuery(sql, "%" + keyword + "%") 
                            : Jdbc.executeQuery(sql);

            while (rs.next()) {
                Employee model = new Employee();
                model.setId(rs.getString("Id"));
                model.setPassword(rs.getString("Password"));
                model.setFullname(rs.getString("Fullname"));
                model.setPhoto(rs.getString("Photo"));
                model.setGender(rs.getBoolean("Gender"));
                model.setBirthday(rs.getString("Birthday"));
                model.setSalary(rs.getDouble("Salary"));
                model.setDepartmentId(rs.getString("DepartmentId"));
                list.add(model);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}