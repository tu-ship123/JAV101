package poly.com.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet({"/bai3FormServlet","/from/ud","/form/create"})
public class Bai3FormServlet extends HttpServlet {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
//	bai4 bean = new bai4();
//	bean.setFullname("Nguyễn Văn Tèo");
//	bean.setGender(true);
//	bean.setCountry("VN");
//	req.setAttribute("user", bean);
	
	Map<String, Object> map = new HashMap<>();
	map.put("fullname", "Nguyễn Ngọc Tú");
	map.put("gender", true);
	map.put("country", "vn");
	req.setAttribute("user", map);
	req.getRequestDispatcher("/form/form.jsp").forward(req, resp);
}
@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uri = req.getRequestURI();
		if (uri.contains("/form/ud"))
		{
		    String fullname = req.getParameter("fullname");
		    String gender = req.getParameter("gender");
		    String country = req.getParameter("country");
	
		    Map<String, Object> map = new HashMap<>();
		    map.put("fullname", fullname);
		    map.put("gender", gender);
		    map.put("country", country);
		    req.setAttribute("user", map);
		    req.setAttribute("capnhat", "update success");
		    req.getRequestDispatcher("/form/form.jsp").forward(req, resp);
		}
		else if (uri.contains("/form/create"))
		{
		    String fullname = req.getParameter("fullname");
		    String gender = req.getParameter("gender");
		    String country = req.getParameter("country");
	
		    Map<String, Object> map = new HashMap<>();
		    map.put("fullname", fullname);
		    map.put("gender", gender);
		    map.put("country", country);
		    req.setAttribute("user", map);
		    req.getRequestDispatcher("/form/themmoi.jsp").forward(req, resp);
		}
	}
}
