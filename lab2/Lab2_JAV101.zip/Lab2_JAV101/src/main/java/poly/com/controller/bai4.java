package poly.com.controller;

public class bai4 {
	private String fullname;
    private boolean gender;
    private String country;

    // constructor mặc định (nên có)
    public bai4() {
    }
    
    // constructor có tham số (tùy chọn)
    public bai4(String fullname, boolean gender, String country) {
        this.fullname = fullname;
        this.gender = gender;
        this.country = country;
    }

    // Các phương thức Getters
    public String getFullname() {
        return fullname;
    }

    // Các phương thức Setters
    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public boolean isGender() {
        return gender;
    }

    public void setGender(boolean gender) {
        this.gender = gender;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
    
}
