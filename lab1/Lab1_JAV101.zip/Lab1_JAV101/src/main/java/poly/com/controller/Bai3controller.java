package poly.com.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/bai3")
public class Bai3controller extends HttpServlet {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	resp.setContentType("text/html;charset=UTF-8");
    var out = resp.getWriter();

    out.println("<html><body>");
    out.println("<h2>Thông tin URL hiện tại:</h2>");
    out.println("<ul>");
    out.println("<li><b>URL:</b> " + req.getRequestURL().toString() + "</li>");
    out.println("<li><b>URI:</b> " + req.getRequestURI() + "</li>");
    out.println("<li><b>QueryString:</b> " + req.getQueryString() + "</li>");
    out.println("<li><b>ServletPath:</b> " + req.getServletPath() + "</li>");
    out.println("<li><b>ContextPath:</b> " + req.getContextPath() + "</li>");
    out.println("<li><b>PathInfo:</b> " + req.getPathInfo() + "</li>");
    out.println("<li><b>Method:</b> " + req.getMethod() + "</li>");
    out.println("</ul>");
    out.println("</body></html>");
}
}