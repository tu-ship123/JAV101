package poly.com.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet({"/bai4", "/crud/create", "/crud/update", "/crud/delete", "/crud/edit/2024"})
public class Bai4controller extends HttpServlet {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	resp.setContentType("text/html;charset=UTF-8");
    var out = resp.getWriter();
    String path = req.getServletPath() + (req.getPathInfo() != null ? req.getPathInfo() : "");

    out.println("<html><body>");
    out.println("<h2>Kết quả thao tác:</h2>");

    switch (path) {
        case "/crud/create":
            out.println("<p><b>Thực hiện chức năng:</b> Tạo mới dữ liệu (Create)</p>");
            break;
        case "/crud/update":
            out.println("<p><b>Thực hiện chức năng:</b> Cập nhật dữ liệu (Update)</p>");
            break;
        case "/crud/delete":
            out.println("<p><b>Thực hiện chức năng:</b> Xóa dữ liệu (Delete)</p>");
            break;
        case "/crud/edit/2024":
            out.println("<p><b>Thực hiện chức năng:</b> Chỉnh sửa dữ liệu có ID = 2024 (Edit)</p>");
            break;
        default:
            out.println("<p><b>Không xác định chức năng!</b></p>");
    }

    out.println("<hr>");
    out.println("<p><i>Đường dẫn bạn đang truy cập:</i> " + path + "</p>");
    out.println("</body></html>");
}
}