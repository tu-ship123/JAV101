package poly.com.comtroller;

import poly.com.bean.Staff;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;
import org.apache.commons.beanutils.converters.DateTimeConverter;

import java.io.IOException;
import java.util.Date;

@WebServlet("/save")
public class Bai1_StaffServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Chuyển hướng đến trang nhập liệu
        req.getRequestDispatcher("/views/staff.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Tạo đối tượng Bean
        Staff bean = new Staff();
        
        try {
            // Cấu hình DateConverter
            DateTimeConverter dtc = new DateConverter(new Date());
            dtc.setPattern("MM/dd/yyyy");
            
            // Đăng ký converter (quan trọng: dùng java.util.Date.class)
            ConvertUtils.register(dtc, java.util.Date.class);

            // Đổ dữ liệu từ form vào bean
            BeanUtils.populate(bean, req.getParameterMap());

            // In kiểm tra
            System.out.println("Họ tên: " + bean.getFullname());
            System.out.println("Ngày sinh: " + bean.getBirthday());
            System.out.println("Quốc tịch: " + bean.getCountry());

            // Gửi dữ liệu sang JSP
            req.setAttribute("staff", bean);
            req.setAttribute("message", "Đã lưu thông tin thành công!");

        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("message", "Có lỗi xảy ra: " + e.getMessage());
        }

        // Quay lại trang form
        req.getRequestDispatcher("/views/staff.jsp").forward(req, resp);
    }
}